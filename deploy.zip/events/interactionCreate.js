// events/interactionCreate.js
// เวอร์ชันนี้เราไม่ใช้ เพราะรวมไว้ใน index.js แล้ว (เผื่อ Dev อยากคุมแยก)
module.exports = () => {};