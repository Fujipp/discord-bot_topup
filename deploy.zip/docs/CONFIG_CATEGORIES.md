# 📂 Config Categories

## หมวดหมู่การตั้งค่า

ระบบ Config แบ่งเป็น 5 หมวดหมู่หลัก:

### 🏦 SlipOK (ธนาคาร/QR)
การตั้งค่าสำหรับระบบตรวจสอบสลิปธนาคารและ QR Code

**Config Keys:**
- `API_SLIPOK_KEY` - API Key จาก SlipOK
- `SLIPOK_BRANCH_ID` - รหัส Branch ID
- `เบอร์รับเงินพ้อมเพย์` - เบอร์ PromptPay สำหรับรับเงิน
- `เติมเงินขั้นต่ำของธนาคาร` - ยอดขั้นต่ำที่ต้องเติม (บาท)

**การใช้งาน:**
```javascript
const slipokKey = ConfigManager.get('API_SLIPOK_KEY');
const branchId = ConfigManager.get('SLIPOK_BRANCH_ID');
const ppPhone = ConfigManager.get('เบอร์รับเงินพ้อมเพย์');
const minAmount = ConfigManager.get('เติมเงินขั้นต่ำของธนาคาร', '5');
```

---

### 🧧 TrueMoney Wallet
การตั้งค่าสำหรับระบบซองอั่งเปา TrueMoney

**Config Keys:**
- `API_TRUEMONEY_KEY_ID` - API Key สำหรับ TrueMoney Voucher
- `เบอร์รับเงินวอเลท` - เบอร์รับเงินวอเลท (10 หลัก)
- `TRUEMONEY_BASE` - Base URL ของ TrueMoney API Service

**การใช้งาน:**
```javascript
const tmKeyId = ConfigManager.get('API_TRUEMONEY_KEY_ID');
const tmPhone = ConfigManager.get('เบอร์รับเงินวอเลท');
const tmBase = ConfigManager.get('TRUEMONEY_BASE', 'https://true-wallet-voucher-production.up.railway.app');
```

---

### 📢 Discord Channels
การตั้งค่าช่องใน Discord

**Config Keys:**
- `ไอดีช่องเช็คสลิป` - Channel ID สำหรับส่งสลิป
- `ไอดีช่องแจ้งเตือนเติมเงิน` - Channel ID สำหรับแจ้งเตือนเติมเงินสำเร็จ

**การใช้งาน:**
```javascript
const checkChannel = ConfigManager.get('ไอดีช่องเช็คสลิป');
const notifyChannel = ConfigManager.get('ไอดีช่องแจ้งเตือนเติมเงิน');

// ใช้ใน Discord.js
const channel = client.channels.cache.get(checkChannel);
```

---

### 👥 Discord Roles
การตั้งค่ายศใน Discord

**Config Keys:**
- `ยศไอดีเช็คสลิป` - Role ID ของผู้มีสิทธิ์เช็คสลิป
- `ไอดียศได้รับเมื่อเติมเงิน` - Role ID ให้เมื่อเติมเงินสำเร็จ

**การใช้งาน:**
```javascript
const checkerRole = ConfigManager.get('ยศไอดีเช็คสลิป');
const memberRole = ConfigManager.get('ไอดียศได้รับเมื่อเติมเงิน');

// เช็คว่ามี role
if (member.roles.cache.has(checkerRole)) {
  // ทำอะไรบางอย่าง
}

// เพิ่ม role
await member.roles.add(memberRole);
```

---

### ⚙️ ตั้งค่าระบบ
การตั้งค่าทั่วไปของระบบ

**Config Keys:**
- `ปรับกำหนดเวลาเช็คสลิป` - ระยะเวลาให้เช็คสลิป (วินาที)
- `เมนูระบบใช้งานธนาคาร` - เปิด/ปิดการใช้งานระบบธนาคาร (boolean)

**การใช้งาน:**
```javascript
const checkTime = ConfigManager.get('ปรับกำหนดเวลาเช็คสลิป', '5');
const bankEnabled = ConfigManager.get('เมนูระบบใช้งานธนาคาร', false);

// ใช้
setTimeout(() => {
  // ทำอะไรบางอย่าง
}, Number(checkTime) * 1000);

if (bankEnabled) {
  // เปิดใช้งานธนาคาร
}
```

---

## การดูการตั้งค่าแยกหมวดหมู่

### ผ่าน Discord UI

1. พิมพ์ `/setup`
2. คลิก "📋 ดูการตั้งค่าทั้งหมด"
3. เลือกหมวดหมู่จาก dropdown menu

### ผ่าน Code

```javascript
const ConfigManager = require('./utils/configManager');
const ConfigEmbed = require('./utils/configEmbed');

// ดูทั้งหมดแบ่งตามหมวดหมู่
const grouped = ConfigManager.getConfigByCategory();

// grouped = {
//   'slipok': {
//     label: '🏦 SlipOK (ธนาคาร/QR)',
//     items: [...]
//   },
//   'truemoney': {
//     label: '🧧 TrueMoney Wallet',
//     items: [...]
//   },
//   ...
// }

// แสดง embed หมวดหมู่เฉพาะ
const slipokEmbed = ConfigEmbed.buildCategoryEmbed('slipok');
await interaction.reply({ embeds: [slipokEmbed] });
```

---

## การเพิ่มหมวดหมู่ใหม่

แก้ไขไฟล์ `utils/configManager.js`:

```javascript
static getSchema() {
  return {
    // เพิ่ม config ใหม่
    'MY_NEW_CONFIG': {
      label: '🆕 ชื่อ Config',
      description: 'คำอธิบาย',
      category: 'my_category',        // ← หมวดหมู่
      categoryLabel: '📁 หมวดหมู่ใหม่', // ← ชื่อหมวดหมู่
      type: 'text',                    // ← ประเภท
      required: false,
      order: 1,                        // ← ลำดับในหมวดหมู่
    },
  };
}
```

แล้วเพิ่มในส่วน UI:

```javascript
// interactions/configInteractions.js
.addOptions([
  // ... existing options
  {
    label: "หมวดหมู่ใหม่",
    description: "ดูการตั้งค่าใหม่",
    emoji: "📁",
    value: "my_category",
  },
]);
```

---

## Progress Bar

ระบบจะแสดง Progress Bar สำหรับแต่ละหมวดหมู่:

```
📊 ความสมบูรณ์
████████████░░░░░░░░ 60%
3/5 รายการ
```

**การคำนวณ:**
- แสดงจำนวนรายการที่ตั้งค่าแล้ว / ทั้งหมด
- แสดง percentage
- แสดง progress bar visual

---

## Environment Variables Priority

แต่ละหมวดหมู่รองรับ Environment Variables:

```
🏦 SlipOK
├── ✅ API Key [ENV]         ← อ่านจาก .env
├── ✅ Branch ID              ← อ่านจาก config file
├── ❌ เบอร์ PromptPay        ← ยังไม่ได้ตั้ง
└── ✅ จำนวนต่ำสุด           ← อ่านจาก config file
```

**สัญลักษณ์:**
- `[ENV]` - อ่านจาก Environment Variable
- (ไม่มี tag) - อ่านจาก Config File
- ✅ - ตั้งค่าแล้ว
- ❌ - ยังไม่ได้ตั้ง
